# Detect Android early (before project()). ANDROID_ABI is a cache variable
# passed via -D when cross-compiling with the NDK toolchain.
if(ANDROID_ABI)
  set(OB_ANDROID ON)
  message(STATUS "Android NDK cross-compilation detected (ABI: ${ANDROID_ABI})")
else()
  set(OB_ANDROID OFF)
endif()

ob_define(DEBUG_PREFIX "-fdebug-prefix-map=${CMAKE_SOURCE_DIR}=.")
ob_define(FILE_PREFIX "-ffile-prefix-map=${CMAKE_SOURCE_DIR}=.")
ob_define(OB_LD_BIN ld)
ob_define(DEP_3RD_DIR "${CMAKE_SOURCE_DIR}/deps/3rd")
ob_define(DEVTOOLS_DIR "${CMAKE_SOURCE_DIR}/deps/3rd/usr/local/oceanbase/devtools")
ob_define(DEP_DIR "${CMAKE_SOURCE_DIR}/deps/3rd/usr/local/oceanbase/deps/devel")

# Deprecated no-op retained for compatibility with existing build invocations.
ob_define(BUILD_EMBED_MODE OFF)
if(BUILD_EMBED_MODE)
  message(STATUS "BUILD_EMBED_MODE is deprecated and has no effect")
endif()
ob_define(OB_USE_CLANG ON)
ob_define(OB_USE_LLD ON)
ob_define(OB_ERRSIM OFF)
ob_define(OB_SO_CACHE OFF)
ob_define(BUILD_NUMBER 1)
ob_define(OB_CMAKE_RULES_CHECK ON)
ob_define(OB_BUILD_CCLS OFF)
ob_define(LTO_JOBS all)
ob_define(LTO_CACHE_DIR "${CMAKE_BINARY_DIR}/cache")
ob_define(LTO_CACHE_POLICY cache_size=100%:cache_size_bytes=0k:cache_size_files=0:prune_after=0s:prune_interval=72h)
ob_define(NEED_PARSER_CACHE ON)
# get compiler from build.sh
ob_define(OB_CC "")
ob_define(OB_CXX "")
ob_define(DEFAULT_LOG_LEVEL OB_LOG_LEVEL_ERROR)
ob_define(DEFAULT_LOG_FILE_SIZE_MB 256)

# begin of unity build config
ob_define(OB_MAX_UNITY_BATCH_SIZE 30)
# the global switch of unity build, default is 'ON'
ob_define(OB_ENABLE_UNITY ON)

ob_define(OB_DISABLE_LSE OFF)

ob_define(OB_DISABLE_PIE ON)

ob_define(OB_ENABLE_MCMODEL OFF)

ob_define(USE_LTO_CACHE OFF)

# 开源模式默认支持系统租户使用向量索引
ob_define(OB_BUILD_SYS_VEC_IDX ON)

# The course/reference integration spells the optional AMD backend CUVS.
# Resolve that build flag as well as the explicit HIPVS spelling so a valid
# course command cannot silently produce a CPU-only binary.
if(DEFINED OB_BUILD_CUVS)
  if(DEFINED OB_BUILD_HIPVS AND
     ((OB_BUILD_CUVS AND NOT OB_BUILD_HIPVS) OR
      (OB_BUILD_HIPVS AND NOT OB_BUILD_CUVS)))
    message(FATAL_ERROR "OB_BUILD_CUVS and OB_BUILD_HIPVS must agree when both are set")
  endif()
  ob_define(OB_BUILD_HIPVS "${OB_BUILD_CUVS}")
endif()
ob_define(OB_BUILD_HIPVS OFF)
if(OB_BUILD_HIPVS)
  if(NOT CMAKE_HOST_SYSTEM_NAME STREQUAL "Linux")
    message(FATAL_ERROR "hipVS construction requires Linux with glibc and ROCm")
  endif()
  add_definitions(-DOB_BUILD_HIPVS)
endif()

if(WIN32)
  EXECUTE_PROCESS(COMMAND powershell -NoProfile -Command "$env:PROCESSOR_ARCHITECTURE"
    OUTPUT_VARIABLE ARCHITECTURE)
  STRING(TOLOWER "${ARCHITECTURE}" ARCHITECTURE)
  STRING(STRIP "${ARCHITECTURE}" ARCHITECTURE)
elseif(OB_ANDROID)
  set(ARCHITECTURE "aarch64")
elseif(CMAKE_SYSTEM_NAME STREQUAL "iOS")
  set(ARCHITECTURE "arm64")
else()
  EXECUTE_PROCESS(COMMAND uname -m COMMAND tr -d '\n' OUTPUT_VARIABLE ARCHITECTURE)
endif()
message(STATUS "ARCHITECTURE: ${ARCHITECTURE}")

if(WITH_COVERAGE)
  set(CMAKE_COVERAGE_COMPILE_OPTIONS -fprofile-instr-generate -fcoverage-mapping -mllvm -runtime-counter-relocation -DWITH_COVERAGE)
  set(CMAKE_COVERAGE_EXE_LINKER_OPTIONS "-fprofile-instr-generate -Wl,-u,__llvm_profile_reset_counters -Wl,-u,__llvm_profile_set_filename -Wl,-u,__llvm_profile_write_file")

  add_compile_options(${CMAKE_COVERAGE_COMPILE_OPTIONS})
  set(DEBUG_PREFIX "")
  set(FILE_PREFIX "")
endif()

ob_define(AUTO_FDO_OPT "")
if(ENABLE_AUTO_FDO)
  if( ${ARCHITECTURE} STREQUAL "x86_64" )
    set(AUTO_FDO_PATH "${CMAKE_SOURCE_DIR}/profile/observer-x86_64.prof")
  elseif( ${ARCHITECTURE} STREQUAL "aarch64" )
    set(AUTO_FDO_PATH "${CMAKE_SOURCE_DIR}/profile/observer-aarch64.prof")
  endif()
  # observer-<arch>.prof is a placeholder with no real samples; replace it to enable AutoFDO.
  set(AUTO_FDO_OPT "-finline-functions -fprofile-sample-use=${AUTO_FDO_PATH}")
  message(STATUS "auto fdo path: " ${AUTO_FDO_PATH})
endif()

ob_define(THIN_LTO_OPT "")
ob_define(THIN_LTO_CONCURRENCY_LINK "")

if(ENABLE_THIN_LTO)
  set(THIN_LTO_OPT "-flto=thin")
  if(APPLE)
    set(THIN_LTO_CONCURRENCY_LINK "-flto-jobs=${LTO_JOBS}")
  else()
    set(THIN_LTO_CONCURRENCY_LINK "-Wl,--thinlto-jobs=${LTO_JOBS}")
    if(USE_LTO_CACHE)
      set(THIN_LTO_CONCURRENCY_LINK "${THIN_LTO_CONCURRENCY_LINK},--thinlto-cache-dir=${LTO_CACHE_DIR},--thinlto-cache-policy=${LTO_CACHE_POLICY}")
    endif()
  endif()
endif()

set(HOTFUNC_OPT "")
if(ENABLE_HOTFUNC)
  if( ${ARCHITECTURE} STREQUAL "x86_64" )
    set(HOTFUNC_PATH "${CMAKE_SOURCE_DIR}/profile/hotfuncs-x86_64.txt")
  elseif( ${ARCHITECTURE} STREQUAL "aarch64" )
    set(HOTFUNC_PATH "${CMAKE_SOURCE_DIR}/profile/hotfuncs-aarch64.txt")
  endif()
  # hotfuncs-<arch>.txt is a placeholder with one unused symbol; replace it to enable ordering.
  set(HOTFUNC_OPT "-Wl,--no-warn-symbol-ordering,--symbol-ordering-file,${HOTFUNC_PATH}")
  message(STATUS "hotfunc path: " ${HOTFUNC_PATH})
endif()

message(STATUS "Using C++20 standard")
if(WIN32)
  set(CMAKE_CXX_FLAGS "/std:c++20")
  set(DEBUG_PREFIX "")
  set(FILE_PREFIX "")
elseif(OB_ANDROID)
  set(CMAKE_CXX_STANDARD 20)
  set(CMAKE_CXX_STANDARD_REQUIRED ON)
  set(CMAKE_CXX_EXTENSIONS ON)
else()
  set(CMAKE_CXX_FLAGS "-std=gnu++20")
endif()

if(OB_DISABLE_PIE)
  message(STATUS "build without pie")
  set(PIE_OPT "-no-pie")
else()
  message(STATUS "build with pie")
  set(PIE_OPT "-pie")
endif()

set(ob_close_deps_static_name "")

if (OB_BUILD_SYS_VEC_IDX)
 add_definitions(-DOB_BUILD_SYS_VEC_IDX)
endif()

# Find objcopy - on macOS it may be installed via Homebrew or available as llvm-objcopy
set(OB_CLANG_BIN "clang-17")
set(OB_CLANGXX_BIN "clang++-17")

add_definitions(-DDEFAULT_LOG_LEVEL=${DEFAULT_LOG_LEVEL})
add_definitions(-DDEFAULT_LOG_FILE_SIZE_MB=${DEFAULT_LOG_FILE_SIZE_MB})
add_definitions(-D_GLIBCXX_USE_CXX11_ABI=1)

set(OB_OBJCOPY_BIN "${DEVTOOLS_DIR}/bin/objcopy")
set(CMAKE_TOOLCHAIN_PATH "${DEVTOOLS_DIR}")
set(GCC_DEVTOOL_PATH "${CMAKE_SOURCE_DIR}/deps/3rd/usr/local/oceanbase")
set(COMPACT_UNWIND_FLAG "")
if(OB_ANDROID)
  # Android NDK: compilers set by toolchain file, no RELRO, no devtools.
  # Must be checked before APPLE since APPLE is true on macOS host even during cross-compile,
  # and Env.cmake runs before project() which would set ANDROID.
  set(OB_CLANG_BIN "clang")
  set(OB_CLANGXX_BIN "clang++")
  # NDK toolchain bin dir (derive from ANDROID_NDK_HOME or
  # CMAKE_TOOLCHAIN_FILE).  Discover the NDK host tag instead of assuming the
  # cross-compile is launched from macOS; Linux hosts use linux-x86_64.
  if(DEFINED ENV{ANDROID_NDK_HOME})
    file(GLOB _NDK_TOOLCHAIN_BIN
      "$ENV{ANDROID_NDK_HOME}/toolchains/llvm/prebuilt/*/bin")
  else()
    # Derive from toolchain file path: .../build/cmake/android.toolchain.cmake -> .../toolchains/llvm/prebuilt/*/bin
    get_filename_component(_NDK_ROOT "${CMAKE_TOOLCHAIN_FILE}" DIRECTORY)
    get_filename_component(_NDK_ROOT "${_NDK_ROOT}" DIRECTORY)
    get_filename_component(_NDK_ROOT "${_NDK_ROOT}" DIRECTORY)
    file(GLOB _NDK_TOOLCHAIN_BIN "${_NDK_ROOT}/toolchains/llvm/prebuilt/*/bin")
  endif()
  list(LENGTH _NDK_TOOLCHAIN_BIN _NDK_TOOLCHAIN_BIN_COUNT)
  if(NOT _NDK_TOOLCHAIN_BIN_COUNT EQUAL 1)
    message(FATAL_ERROR
      "Expected exactly one Android NDK host toolchain, found: ${_NDK_TOOLCHAIN_BIN}")
  endif()
  list(GET _NDK_TOOLCHAIN_BIN 0 _NDK_TOOLCHAIN_BIN)
  set(OB_CC "${_NDK_TOOLCHAIN_BIN}/clang")
  set(OB_CXX "${_NDK_TOOLCHAIN_BIN}/clang++")
  set(OB_LD_BIN "${_NDK_TOOLCHAIN_BIN}/ld.lld")
  set(OB_OBJCOPY_BIN "${_NDK_TOOLCHAIN_BIN}/llvm-objcopy")
  message(STATUS "NDK toolchain bin: ${_NDK_TOOLCHAIN_BIN}")
elseif(CMAKE_SYSTEM_NAME STREQUAL "iOS")
  # iOS toolchain details are initialized by IOS.cmake. Do not infer macOS
  # host deployment settings for the cross-compiled target.
  set(OB_MACOS27 OFF)
  ob_define(SYS_INCLUDE_DIR "/usr")
  add_definitions(-D_DARWIN_C_SOURCE)
  set(OB_CLANG_BIN "clang")
  set(OB_CLANGXX_BIN "clang++")
  set(CMAKE_TOOLCHAIN_PATH "/usr")
  set(GCC_DEVTOOL_PATH "/usr/lib/")
elseif(APPLE)
  ob_define(SYS_INCLUDE_DIR "/usr")
  add_definitions(-D_DARWIN_C_SOURCE)
  set(OB_CLANG_BIN "clang")
  set(OB_CLANGXX_BIN "clang++")
  set(CMAKE_TOOLCHAIN_PATH "/usr")
  set(GCC_DEVTOOL_PATH "/usr/lib/")
  # Set macOS deployment target to match the current system version
  # This eliminates linker warnings when linking with Homebrew libraries
  execute_process(
    COMMAND sw_vers -productVersion
    OUTPUT_VARIABLE MACOS_VERSION
    OUTPUT_STRIP_TRAILING_WHITESPACE
  )
  set(CMAKE_OSX_DEPLOYMENT_TARGET "${MACOS_VERSION}" CACHE STRING "Minimum macOS deployment version")
  # extract major version like 15.6.1 -> 15
  string(REPLACE "." ";" MACOS_VERSION_LISTS "${MACOS_VERSION}")
  list(GET MACOS_VERSION_LISTS 0 MACOS_MAJOR)
  if(MACOS_MAJOR GREATER_EQUAL 27)
    include("${CMAKE_CURRENT_LIST_DIR}/MacOS27.cmake")
  endif()
  if(MACOS_MAJOR LESS 15)
    set(COMPACT_UNWIND_FLAG "-Wl,-no_compact_unwind")
  endif()
elseif(WIN32)
  set(OB_CC "clang-cl")
  set(OB_CXX "clang-cl")
  add_definitions(-DWIN32_LEAN_AND_MEAN -DNOMINMAX)

  # All bundled / vcpkg-provided vendor libraries (s2.lib,
  # zlib.lib, ...) are built against the Release MSVC runtime. Using /MDd
  # in a Debug build makes MSVC STL set _ITERATOR_DEBUG_LEVEL=2, which
  # then trips #pragma detect_mismatch at link time against those
  # vendor .obj files built with _ITERATOR_DEBUG_LEVEL=0. Force the
  # Release runtime (MultiThreadedDLL) for all configs on Windows and
  # pin _ITERATOR_DEBUG_LEVEL=0 to match vendor libs.
  cmake_policy(SET CMP0091 NEW)
  set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreadedDLL"
      CACHE STRING "MSVC runtime library (must match vendor libs)" FORCE)
  add_definitions(-D_ITERATOR_DEBUG_LEVEL=0)
  # vcpkg ships both Release (lib/) and Debug (debug/lib/) variants of
  # several libraries (gRPC, protobuf, abseil, ...). In a Debug build CMake
  # would otherwise resolve imported targets from find_package(... CONFIG)
  # to the /MDd + _ITERATOR_DEBUG_LEVEL=2 Debug variant and trip
  # #pragma detect_mismatch at link time. Map every non-Release config to
  # Release so imported targets always resolve to the Release .lib that
  # matches our CRT. These must be set at top-level (Env.cmake is included
  # before project() in root CMakeLists.txt) so the mapping is in scope of
  # every target that links against such imported libs.
  set(CMAKE_MAP_IMPORTED_CONFIG_DEBUG Release)
  set(CMAKE_MAP_IMPORTED_CONFIG_RELWITHDEBINFO Release)
  set(CMAKE_MAP_IMPORTED_CONFIG_MINSIZEREL Release)
  # /RTC1 requires the debug CRT; strip it so Debug builds can use /MD.
  foreach(_flag_var
          CMAKE_C_FLAGS_DEBUG CMAKE_CXX_FLAGS_DEBUG
          CMAKE_C_FLAGS_RELWITHDEBINFO CMAKE_CXX_FLAGS_RELWITHDEBINFO)
    if(DEFINED ${_flag_var})
      string(REGEX REPLACE "[ \t]*/RTC[^ \t]*" "" ${_flag_var} "${${_flag_var}}")
    endif()
  endforeach()
  unset(_flag_var)
  ob_define(SYS_UM_INCLUDE_DIR "C:/Program Files (x86)/Windows Kits/10/Include/10.0.26100.0/um")
  ob_define(SYS_UCRT_INCLUDE_DIR "C:/Program Files (x86)/Windows Kits/10/Include/10.0.26100.0/ucrt")
  ob_define(SYS_SHARED_INCLUDE_DIR "C:/Program Files (x86)/Windows Kits/10/Include/10.0.26100.0/shared")
  ob_define(OB_VCPKG_DIR "C:/VcpkgInstalled/x64-windows")
  ob_define(OB_OPENSSL_DIR "C:/Program Files/OpenSSL-Win64")
  ob_define(OB_LLVM_DIR "C:/Program Files/LLVM18")
  ob_define(OB_VSAG_DIR "${DEP_3RD_DIR}/vsag")
  # These paths may arrive from -D... with native Windows backslashes. If we
  # let them flow unchanged into configure_file()/file(WRITE) outputs, CMake
  # 3.20+ will reject the resulting scripts with "Invalid character escape"
  # (\w, \d, \x, ...). Normalize once here so all downstream uses are safe.
  foreach(_ob_path_var
          SYS_UM_INCLUDE_DIR SYS_UCRT_INCLUDE_DIR SYS_SHARED_INCLUDE_DIR
          OB_VCPKG_DIR OB_OPENSSL_DIR OB_LLVM_DIR OB_VSAG_DIR)
    if(DEFINED ${_ob_path_var})
      file(TO_CMAKE_PATH "${${_ob_path_var}}" ${_ob_path_var})
    endif()
  endforeach()
  unset(_ob_path_var)
elseif(UNIX)
  # NO RELERO: -Wl,-znorelro
  # Partial RELRO: -Wl,-z,relro
  # Full RELRO: -Wl,-z,relro,-z,now
  # macOS doesn't support RELRO flags
  ob_define(OB_RELRO_FLAG "-Wl,-z,relro,-z,now")
endif()

ob_define(OB_USE_CCACHE OFF)
if (OB_USE_CCACHE)
  find_program(OB_CCACHE ccache PATHS "${DEVTOOLS_DIR}/bin" NO_DEFAULT_PATH)
  if (NOT OB_CCACHE)
    message(FATAL_ERROR "cannot find ccache.")
  else()
    set(CMAKE_C_COMPILER_LAUNCHER ${OB_CCACHE})
    set(CMAKE_CXX_COMPILER_LAUNCHER ${OB_CCACHE})
  endif()
endif(OB_USE_CCACHE)

if (OB_USE_CLANG)

  if (OB_CC)
    message(STATUS "Using OB_CC compiler: ${OB_CC}")
  else()
    find_program(OB_CC ${OB_CLANG_BIN}
    "${DEVTOOLS_DIR}/bin"
      NO_DEFAULT_PATH)
  endif()

  if (OB_CXX)
    message(STATUS "Using OB_CXX compiler: ${OB_CXX}")
  else()
    find_program(OB_CXX ${OB_CLANGXX_BIN}
    "${DEVTOOLS_DIR}/bin"
      NO_DEFAULT_PATH)
  endif()

  if(NOT OB_ANDROID AND NOT OB_MACOS27)
    set(OB_OBJCOPY_BIN "${DEVTOOLS_DIR}/bin/llvm-objcopy")
  endif()

  find_file(GCC9 devtools
    PATH ${GCC_DEVTOOL_PATH}
    NO_DEFAULT_PATH)
  set(_CMAKE_TOOLCHAIN_PREFIX llvm-)
  set(_CMAKE_TOOLCHAIN_LOCATION "${CMAKE_TOOLCHAIN_PATH}/bin")

  if (OB_USE_LLD)
    if(OB_ANDROID)
      # Android: OB_LD_BIN already set in platform block above
    elseif(APPLE)
      set(LD_OPT "-Wl,-dead_strip")
      set(REORDER_COMP_OPT "-ffunction-sections -fdata-sections")
      set(REORDER_LINK_OPT "-Wl,-dead_strip")
      if(NOT OB_MACOS27)
        set(OB_LD_BIN "ld")
      endif()
    elseif(WIN32)
      set(LD_OPT "/INCREMENTAL:NO")
      set(REORDER_COMP_OPT "")
      set(REORDER_LINK_OPT "/OPT:REF /OPT:ICF ${HOTFUNC_OPT}")
      set(OB_LD_BIN "lld-link")
      set(OB_LIB_BIN "llvm-lib")
    elseif(UNIX)
      set(LD_OPT "-fuse-ld=${DEVTOOLS_DIR}/bin/ld.lld -Wno-unused-command-line-argument")
      set(REORDER_COMP_OPT "-ffunction-sections -fdata-sections -fdebug-info-for-profiling")
      set(REORDER_LINK_OPT "-Wl,--no-rosegment,--build-id=sha1,--gc-sections,--icf=all ${HOTFUNC_OPT}")
      set(OB_LD_BIN "${DEVTOOLS_DIR}/bin/ld.lld")
    endif()
  endif()

  if(OB_MACOS27)
    # CMAKE_LINKER alone does not control the linker invoked by clang.
    string(APPEND LD_OPT " --ld-path=\"${OB_LD_BIN}\"")
  endif()

  if(OB_ANDROID)
    # Android NDK: no --gcc-toolchain, no macOS frameworks
    # -D_LIBCPP_ENABLE_CXX17_REMOVED_UNARY_BINARY_FUNCTION: Boost headers use std::unary_function removed in C++17
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} -fcolor-diagnostics ${REORDER_COMP_OPT} -fmax-type-align=8 -D_LIBCPP_ENABLE_CXX17_REMOVED_UNARY_BINARY_FUNCTION")
    set(CMAKE_C_FLAGS "${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} -fcolor-diagnostics ${REORDER_COMP_OPT} -fmax-type-align=8")
    set(CMAKE_CXX_LINK_FLAGS "${LD_OPT} ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT}")
    set(CMAKE_SHARED_LINKER_FLAGS "${LD_OPT} ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT}")
    set(CMAKE_EXE_LINKER_FLAGS "${LD_OPT} ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT} ${CMAKE_COVERAGE_EXE_LINKER_OPTIONS}")
  elseif(APPLE)
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} -fcolor-diagnostics ${REORDER_COMP_OPT} -fmax-type-align=8")
    set(CMAKE_C_FLAGS "${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} -fcolor-diagnostics ${REORDER_COMP_OPT} -fmax-type-align=8")
    set(CMAKE_CXX_LINK_FLAGS "${LD_OPT} ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT}")
    set(CMAKE_SHARED_LINKER_FLAGS "${LD_OPT} ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT} ${COMPACT_UNWIND_FLAG}")
    set(CMAKE_EXE_LINKER_FLAGS "${LD_OPT} ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT} ${CMAKE_COVERAGE_EXE_LINKER_OPTIONS} ${COMPACT_UNWIND_FLAG}")
  elseif(WIN32)
    set(OB_OBJCOPY_BIN "llvm-objcopy")
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} ${REORDER_COMP_OPT}")
    set(CMAKE_C_FLAGS "${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} ${REORDER_COMP_OPT}")
    set(CMAKE_CXX_LINK_FLAGS "${LD_OPT} ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT}")
    set(CMAKE_SHARED_LINKER_FLAGS "/INCREMENTAL:NO ${LD_OPT} ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT} ${COMPACT_UNWIND_FLAG}")
    set(CMAKE_EXE_LINKER_FLAGS "/INCREMENTAL:NO ${LD_OPT} ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT} ${CMAKE_COVERAGE_EXE_LINKER_OPTIONS} ${COMPACT_UNWIND_FLAG}")
  elseif(OB_ANDROID)
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} -fcolor-diagnostics ${REORDER_COMP_OPT} -fmax-type-align=8")
    set(CMAKE_C_FLAGS "${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} -fcolor-diagnostics ${REORDER_COMP_OPT} -fmax-type-align=8")
    set(CMAKE_CXX_LINK_FLAGS "${LD_OPT} ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT}")
    set(CMAKE_SHARED_LINKER_FLAGS "${LD_OPT} ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT}")
    set(CMAKE_EXE_LINKER_FLAGS "${LD_OPT} ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT} ${CMAKE_COVERAGE_EXE_LINKER_OPTIONS}")
  else()
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} --gcc-toolchain=${GCC9} -gdwarf-4 ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} -fcolor-diagnostics ${REORDER_COMP_OPT} -fmax-type-align=8")
    set(CMAKE_C_FLAGS "--gcc-toolchain=${GCC9} -gdwarf-4 ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT} ${THIN_LTO_OPT} -fcolor-diagnostics ${REORDER_COMP_OPT} -fmax-type-align=8")
    set(CMAKE_CXX_LINK_FLAGS "${LD_OPT} --gcc-toolchain=${GCC9} ${DEBUG_PREFIX} ${FILE_PREFIX} ${AUTO_FDO_OPT}")
    set(CMAKE_SHARED_LINKER_FLAGS "${LD_OPT} -Wl,-z,noexecstack ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT}")
    set(CMAKE_EXE_LINKER_FLAGS "${LD_OPT} -Wl,-z,noexecstack ${PIE_OPT} ${THIN_LTO_CONCURRENCY_LINK} ${REORDER_LINK_OPT} ${CMAKE_COVERAGE_EXE_LINKER_OPTIONS}")
  endif()
else() # not clang, use gcc
  message("gcc9 not support currently, please set OB_USE_CLANG ON and we will finish it as soon as possible")
endif()

if (OB_BUILD_CCLS)
  # ccls场景采用更大的unity的联合编译单元，ccls是非完整编译，调用clang AST接口，单元的size和耗时成指数衰减
  set(OB_MAX_UNITY_BATCH_SIZE 200)
  # -DCCLS_LASY_ENABLE 给全局设置上，将采用ccls懒加载模式，主要针对单测case，当添加上-DCCLS_LASY_OFF，首次将会进行检索
  set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -DCCLS_LASY_ENABLE")
  set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -DCCLS_LASY_ENABLE")
endif()

if (OB_CC AND OB_CXX)
  set(CMAKE_C_COMPILER ${OB_CC})
  set(CMAKE_CXX_COMPILER ${OB_CXX})
else()
  message(FATAL_ERROR "can't find suitable compiler")
endif()

find_program(OB_COMPILE_EXECUTABLE ob-compile)
if (NOT OB_COMPILE_EXECUTABLE)
  message(STATUS "ob-compile not found, compile locally.")
else()
  set(CMAKE_C_COMPILER_LAUNCHER ${OB_COMPILE_EXECUTABLE})
  set(CMAKE_CXX_COMPILER_LAUNCHER ${OB_COMPILE_EXECUTABLE})
  set(CMAKE_C_LINKER_LAUNCHER ${OB_COMPILE_EXECUTABLE})
  set(CMAKE_CXX_LINKER_LAUNCHER ${OB_COMPILE_EXECUTABLE})
endif()

option(OB_ENABLE_AVX2 "enable AVX2 and related instruction set support for x86_64" OFF)

include(CMakeFindBinUtils)

if(${ARCHITECTURE} STREQUAL "amd64")
  set(MARCH_CFLAGS "")
  set(MTUNE_CFLAGS "-mtune=generic")
  set(ARCH_LDFLAGS "")
elseif(${ARCHITECTURE} STREQUAL "x86_64")
  set(MTUNE_CFLAGS -mtune=core2)
  set(ARCH_LDFLAGS "")
else()
  if (${OB_DISABLE_LSE})
    message(STATUS "build with no-lse")
    set(MARCH_CFLAGS "-march=armv8-a+crc")
  else()
    message(STATUS "build with lse")
    set(MARCH_CFLAGS "-march=armv8-a+crc+lse")
  endif()
  set(MTUNE_CFLAGS "-mtune=generic" )
  if(OB_ANDROID)
    set(ARCH_LDFLAGS "-latomic")
  elseif(APPLE)
    find_library(ATOMIC_LIB atomic)
    if(ATOMIC_LIB)
      set(ARCH_LDFLAGS "${ATOMIC_LIB}")
    endif()
  else()
    set(ARCH_LDFLAGS "-l:libatomic.a")
  endif()
endif()

# AIO library detection for Ubuntu >= 24.04 and Debian >= 13
# Set OB_AIO_LINK_OPTION for linking and OB_AIO_PACKAGE_DEPENDENCY for package dependencies
set(OB_AIO "libaio")
find_program(LSB_RELEASE_EXEC lsb_release)
if(LSB_RELEASE_EXEC)
  execute_process(
    COMMAND ${LSB_RELEASE_EXEC} -is
    OUTPUT_VARIABLE DEBIAN_NAME
    OUTPUT_STRIP_TRAILING_WHITESPACE
    ERROR_QUIET
  )
  if(DEBIAN_NAME)
    string(TOLOWER "${DEBIAN_NAME}" DEBIAN_NAME)
    execute_process(
      COMMAND ${LSB_RELEASE_EXEC} -rs
      OUTPUT_VARIABLE DEBIAN_VERSION
      OUTPUT_STRIP_TRAILING_WHITESPACE
      ERROR_QUIET
    )
    if(DEBIAN_VERSION)
      # Check for Ubuntu >= 24.04
      if(DEBIAN_NAME STREQUAL "ubuntu")
        if(DEBIAN_VERSION VERSION_GREATER_EQUAL "24.04")
          set(OB_AIO "libaio1t64")
          message(STATUS "Ubuntu ${DEBIAN_VERSION} detected, using ${OB_AIO}")
        endif()
      # Check for Debian >= 13
      elseif(DEBIAN_NAME STREQUAL "debian")
        if(DEBIAN_VERSION VERSION_GREATER_EQUAL "13")
          set(OB_AIO "libaio1t64")
          message(STATUS "Debian ${DEBIAN_VERSION} detected, using ${OB_AIO}")
        endif()
      endif()
    endif()
  endif()
endif()

EXECUTE_PROCESS(COMMAND grep -Po "release [0-9]{1}" /etc/redhat-release COMMAND awk "{print $2}" COMMAND tr -d '\n' OUTPUT_VARIABLE KERNEL_RELEASE ERROR_QUIET)
