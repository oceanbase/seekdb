# 2026-10-31 独立复跑补充包

本包冻结的测试源码为 0e86b8c38afaf8fe3359041645c9b53c5a8524fe。
其构建加速 8.0192 倍，GPU Recall@10 为 1.000 / 0.999 / 1.000。
后续仓库已有构建入口/部署修复；本包不声称这些后续修复用本次二进制测试过。
最新完整工程及主提交材料包位于 https://github.com/sevenmiles666/psfseekdb ，分支 competition/amd-hipvs-build。
本包只含测量相关源码、回归测试、冻结版本说明及本次原始证据，不是独立完整工程。
根 results/sql-50000x128.json 是既有回归测试使用的历史夹具，本次结果在 radeon-20261031-recheck 子目录。

解压后在本包根目录运行：
python -m unittest discover -s unittest/sql/vector_index -p 'test_hipvs_*.py' -v
python docs/gpu-hnsw-build/verify_evidence.py --results-dir docs/gpu-hnsw-build/results/radeon-20261031-recheck

预期 14 项回归通过、verified=true。这是离线核验，不重新执行 GPU。
实际 Linux 二进制另有本地备份，见本次结果目录内 runtime-backup.json。
