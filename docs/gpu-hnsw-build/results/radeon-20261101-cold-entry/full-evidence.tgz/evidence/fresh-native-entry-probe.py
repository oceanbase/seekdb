"""Verify the real contest entry without duplicating the full C++ build."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

ROOT = Path('/workspace/amd-acceptance-20261101-4855acac')
AUDIT = ROOT / 'native-entry'
SRC = AUDIT / 'source'
EVIDENCE = ROOT / 'evidence'
SHA = '4855acac7314df7d43f405b9c73c04ee4d40d562'
report = dict(source_commit=SHA, completed=False, full_cpp_build_repeated=False,
              stage='waiting-for-empty-cache-rust', make_guard_expected_exit=42)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save():
    report['updated_utc'] = datetime.now(timezone.utc).isoformat()
    (EVIDENCE / 'native-entry-status.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)


try:
    save()
    deadline = time.monotonic() + 3900
    while True:
        completion = ROOT / 'cold-rust/completion-status.json'
        cold = json.loads((completion if completion.exists() else ROOT / 'cold-rust/status.json').read_text())
        if cold['stage'] == 'passed':
            break
        if cold['stage'] == 'failed':
            raise RuntimeError('Empty-cache Rust failed: ' + json.dumps(cold))
        if time.monotonic() > deadline:
            raise TimeoutError('Empty-cache Rust has not completed')
        time.sleep(15)
    report['cold_rust'] = cold
    AUDIT.mkdir()
    subprocess.run(['git', 'clone', '--shared', '--no-hardlinks', ROOT / 'src', SRC], check=True)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SRC, text=True).strip() == SHA
    guard = AUDIT / 'stop-before-cpp-build.sh'
    guard.write_text('#!/bin/sh\ncase "$PWD:$*" in\n'
                     f' "{SRC}/build_tgz:"*seekdb*|"{SRC}/build_release:"*seekdb*)\n'
                     '  echo "[native-entry-probe] reached main make: $*"; exit 42 ;;\n'
                     ' *) exec /usr/bin/make "$@" ;;\nesac\n')
    guard.chmod(0o755)
    environment = os.environ.copy()
    for name in ['RUSTC', 'CARGO', 'RUSTUP_TOOLCHAIN', 'RUSTUP_INIT_URL',
                 'RUSTUP_DIST_SERVER', 'RUSTUP_UPDATE_ROOT', 'LD_LIBRARY_PATH',
                 'LD_PRELOAD', 'FORWARDING_HOST', 'SEEKDB_CACHE_NFS_ROOT']:
        environment.pop(name, None)
    cold_root = ROOT / 'cold-rust/install'
    task = AUDIT / 'task'
    environment.update(
        PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/venv/bin:/opt/rocm/bin',
        CARGO_HOME=str(cold_root / 'cargo'), RUSTUP_HOME=str(cold_root / 'rustup'),
        SEEKDB_RUST_INSTALL_ROOT=str(cold_root), GITHUB_WORKSPACE=str(SRC),
        SEEKDB_TASK_DIR=str(task), DEP_CACHE_DIR=str(ROOT / 'exact-deps-cache'),
        PACKAGE_TYPE='tgz', MAKE=str(guard), MAKE_ARGS='-j2')
    report['stage'] = 'real-compile-entry-through-gpu-configure'
    save()
    started = time.monotonic()
    with (EVIDENCE / 'native-entry.log').open('w') as log:
        result = subprocess.run(['bash', SRC / '.github/script/seekdb/compile.sh'],
                                cwd=SRC, env=environment, stdout=log,
                                stderr=subprocess.STDOUT, timeout=900)
    text = (EVIDENCE / 'native-entry.log').read_text()
    report.update(returncode=result.returncode, elapsed_seconds=time.monotonic() - started)
    assert result.returncode == 42, text[-4000:]
    assert '[native-entry-probe] reached main make' in text
    assert '[compile.sh] final phase=build exit=42' in text
    cache = (SRC / 'build_tgz/CMakeCache.txt').read_text().splitlines()
    for name in ['OB_BUILD_CUVS', 'OB_BUILD_HIPVS']:
        assert any(line.startswith(name + ':') and line.endswith('=ON') for line in cache), name
    assert '-DOB_BUILD_HIPVS ' in (SRC / 'build_tgz/src/observer/CMakeFiles/seekdb.dir/flags.make').read_text()
    for target in ['seekdb_hipvs_hnsw', 'seekdb_hipvs_hnsw_worker']:
        assert (SRC / f'build_tgz/src/oblib/lib/CMakeFiles/{target}.dir/build.make').is_file()
    # The farm's default profile is Release; also verify the real default entry.
    environment.pop('PACKAGE_TYPE')
    with (EVIDENCE / 'native-entry-default-release.log').open('w') as log:
        default = subprocess.run(['bash', SRC / '.github/script/seekdb/compile.sh'],
                                 cwd=SRC, env=environment, stdout=log,
                                 stderr=subprocess.STDOUT, timeout=900)
    default_text = (EVIDENCE / 'native-entry-default-release.log').read_text()
    assert default.returncode == 42, default_text[-4000:]
    assert '[compile.sh] final phase=build exit=42' in default_text
    default_cache = (SRC / 'build_release/CMakeCache.txt').read_text().splitlines()
    for name in ['OB_BUILD_CUVS', 'OB_BUILD_HIPVS']:
        assert any(line.startswith(name + ':') and line.endswith('=ON') for line in default_cache), name
    assert '-DOB_BUILD_HIPVS ' in (SRC / 'build_release/src/observer/CMakeFiles/seekdb.dir/flags.make').read_text()
    report['profiles'] = [dict(profile='tgz', main_make_guard_exit=42),
                          dict(profile='default-release', main_make_guard_exit=42)]
    installed = cold_root / 'rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/bin'
    report['compiler_hashes'] = {}
    for name in ['cargo', 'rustc']:
        downloaded = digest(installed / name)
        build_compiler = digest(ROOT / 'tooling/rust-1.98.1/bin' / name)
        assert downloaded == build_compiler, name
        report['compiler_hashes'][name] = downloaded
    expected = json.loads((EVIDENCE / 'source-sha256.json').read_text())
    assert all(digest(SRC / name) == value for name, value in expected.items())
    report.update(completed=True, stage='passed', dependency_cache_reused=True,
                  empty_cache_rust_download_passed=True, compiled_toolchain_identical=True,
                  actual_gpu_configure_passed=True, tracked_files_unchanged=len(expected),
                  note='Real entry passed init/configure and deliberately stopped before main C++ make. Full build and package acceptance run separately on the identical candidate.')
    save()
except Exception as error:
    report.update(stage='failed', error=repr(error))
    save()
    traceback.print_exc()
    raise
