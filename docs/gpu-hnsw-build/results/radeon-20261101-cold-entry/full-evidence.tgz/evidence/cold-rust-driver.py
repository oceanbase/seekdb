import json
import os
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone


root = Path(__file__).resolve().parent
environment = os.environ.copy()
environment["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
for name in (
    "RUSTUP_HOME", "CARGO_HOME", "RUSTUP_TOOLCHAIN", "RUSTUP_INIT_URL",
    "RUSTUP_DIST_SERVER", "RUSTUP_UPDATE_ROOT",
):
    environment.pop(name, None)
environment["CARGO_HOME"] = str(root / "install" / "cargo")
environment["RUSTUP_HOME"] = str(root / "install" / "rustup")
status = {
    "stage": "running",
    "source_commit": "4855acac7314df7d43f405b9c73c04ee4d40d562",
    "no_preseeded_download_cache": True,
    "started_at": datetime.now(timezone.utc).isoformat(),
}


def save():
    status["updated_at"] = datetime.now(timezone.utc).isoformat()
    (root / "status.json").write_text(json.dumps(status, indent=2) + "\n")


save()
started = time.monotonic()
try:
    with (root / "bootstrap.log").open("w") as output:
        result = subprocess.run(
            [
                "bash", "-c",
                'source "$1"; seekdb_prepare_rust "$2" "$3"',
                "cold-probe", str(root / "setup_rust.sh"),
                str(root / "source"), str(root / "install"),
            ],
            env=environment, stdout=output, stderr=subprocess.STDOUT,
            timeout=3600,
        )
    status.update(
        stage="passed" if result.returncode == 0 else "failed",
        returncode=result.returncode,
    )
except Exception as error:
    status.update(stage="failed", error=repr(error))
status["elapsed_seconds"] = time.monotonic() - started
save()
