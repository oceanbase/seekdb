from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import traceback

ROOT = Path('/workspace/amd-acceptance-20261101-4855acac')
SRC = ROOT / 'src'
EVIDENCE = ROOT / 'evidence'
SHA = '4855acac7314df7d43f405b9c73c04ee4d40d562'
stage = 'verify-configured-gpu-build'
prefix = ROOT / 'tooling/rust-1.98.1'
env = os.environ.copy()
env.update(PATH=str(prefix / 'bin') + ':/opt/venv/bin:/opt/rocm/bin:' + env.get('PATH', ''),
           RUSTC=str(prefix / 'bin/rustc'), RUSTUP_TOOLCHAIN='1.98.1',
           CARGO_HOME=str(ROOT / 'tooling/cargo'), CARGO_NET_OFFLINE='true',
           CARGO_BUILD_JOBS='1', MAKEFLAGS='-j4', OMP_NUM_THREADS='8', OPENBLAS_NUM_THREADS='8',
           DEP_CACHE_DIR=str(ROOT / 'exact-deps-cache'))


def status(state, **extra):
    report = dict(stage=stage, state=state, source_commit=SHA, cpp_jobs=4,
                  external_cargo_jobs=1, updated_utc=datetime.now(timezone.utc).isoformat(), **extra)
    (EVIDENCE / 'current-status.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)


def run(args, label):
    with (EVIDENCE / (label + '.log')).open('a') as output:
        output.write(json.dumps({'command': [str(arg) for arg in args]}) + '\n')
        output.flush()
        subprocess.run([str(arg) for arg in args], cwd=SRC, env=env,
                       stdout=output, stderr=subprocess.STDOUT, timeout=7200, check=True)


try:
    status('running')
    previous = json.loads((EVIDENCE / 'driver-cache-guard-status.json').read_text())
    assert previous['stage'] == 'configure-gpu-tgz' and previous['error'] == 'AssertionError()'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SRC, text=True).strip() == SHA
    cache = (SRC / 'build_tgz/CMakeCache.txt').read_text()
    assert re.search(r'^OB_BUILD_CUVS:[^=]+=ON$', cache, re.M)
    flags = (SRC / 'build_tgz/src/observer/CMakeFiles/seekdb.dir/flags.make').read_text()
    assert '-DOB_BUILD_HIPVS ' in flags
    for target in ['seekdb_hipvs_hnsw_worker', 'seekdb_hipvs_hnsw']:
        assert (SRC / f'build_tgz/src/oblib/lib/CMakeFiles/{target}.dir/build.make').exists()
    (EVIDENCE / 'gpu-configuration-verification.json').write_text(json.dumps({
        'passed': True, 'course_alias_on': True, 'observer_hipvs_macro': True,
        'worker_and_bridge_targets_present': True,
        'harness_correction': 'Course alias is UNINITIALIZED; internal HIPVS variable is not a cache entry. Validate actual compiler definitions and generated GPU targets.',
        'source_modified': False, 'configure_repeated': False,
    }, indent=2) + '\n')
    stage = 'compile-gpu'
    status('running')
    run(['make', '-C', SRC / 'build_tgz', '-j4', 'seekdb'], 'compile-gpu')
    stage = 'generate-admin-and-build-all'
    status('running')
    run(['make', '-C', SRC / 'build_tgz', '-j2', 'generate_syspack_source'], 'generate-admin')
    run(['make', '-C', SRC / 'build_tgz', '-j2'], 'build-all')
    expected = json.loads((EVIDENCE / 'source-sha256.json').read_text())
    for name, value in expected.items():
        with (SRC / name).open('rb') as source:
            assert hashlib.file_digest(source, 'sha256').hexdigest() == value, name
    run(['git', 'diff', '--exit-code'], 'final-source-check')
    stage = 'build-passed'
    status('passed', tracked_files_unchanged=len(expected))
except Exception as error:
    status('failed', error=repr(error))
    traceback.print_exc()
    raise
