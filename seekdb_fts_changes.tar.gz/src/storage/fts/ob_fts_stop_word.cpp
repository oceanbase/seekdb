/*
 * Copyright (c) 2025 OceanBase.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "object/ob_object.h"
#define USING_LOG_PREFIX STORAGE_FTS

#include "share/rc/ob_tenant_base.h"
#include "plugin/sys/ob_plugin_mgr.h"
#include "storage/fts/ob_fts_stop_word.h"
#include "storage/fts/ob_fts_plugin_helper.h"
#include "storage/fts/ob_fts_parser_property.h"
#include "storage/fts/ob_fts_plugin_helper.h"

namespace oceanbase
{
namespace storage
{

namespace
{

// Basic English emits lowercase ASCII tokens on its fast path.  Recognizing
// those stop words directly avoids constructing a per-token arena and running
// a general charset conversion/hash comparison.  Non-ASCII input still takes
// the collation-aware path below, so its semantics are unchanged.
bool is_ascii_stopword(const ObString &word, bool &is_ascii)
{
  is_ascii = true;
  for (int64_t i = 0; is_ascii && i < word.length(); ++i) {
    is_ascii = static_cast<unsigned char>(word.ptr()[i]) < 0x80;
  }

  bool is_stopword = false;
  if (is_ascii) {
    switch (word.length()) {
      case 1:
        is_stopword = 0 == word.case_compare("a") || 0 == word.case_compare("i");
        break;
      case 2:
        is_stopword = 0 == word.case_compare("an")
                   || 0 == word.case_compare("as")
                   || 0 == word.case_compare("at")
                   || 0 == word.case_compare("be")
                   || 0 == word.case_compare("by")
                   || 0 == word.case_compare("de")
                   || 0 == word.case_compare("en")
                   || 0 == word.case_compare("in")
                   || 0 == word.case_compare("is")
                   || 0 == word.case_compare("it")
                   || 0 == word.case_compare("la")
                   || 0 == word.case_compare("of")
                   || 0 == word.case_compare("on")
                   || 0 == word.case_compare("or")
                   || 0 == word.case_compare("to");
        break;
      case 3:
        is_stopword = 0 == word.case_compare("are")
                   || 0 == word.case_compare("com")
                   || 0 == word.case_compare("for")
                   || 0 == word.case_compare("how")
                   || 0 == word.case_compare("the")
                   || 0 == word.case_compare("und")
                   || 0 == word.case_compare("was")
                   || 0 == word.case_compare("who")
                   || 0 == word.case_compare("www");
        break;
      case 4:
        is_stopword = 0 == word.case_compare("from")
                   || 0 == word.case_compare("that")
                   || 0 == word.case_compare("this")
                   || 0 == word.case_compare("what")
                   || 0 == word.case_compare("when")
                   || 0 == word.case_compare("will")
                   || 0 == word.case_compare("with");
        break;
      case 5:
        is_stopword = 0 == word.case_compare("about")
                   || 0 == word.case_compare("where");
        break;
      default:
        break;
    }
  }
  return is_stopword;
}

class ObUpdateWordCount
{
public:
  explicit ObUpdateWordCount(const int64_t increment) : increment_(increment) {}
  int operator()(common::hash::HashMapPair<ObFTWord, int64_t> &pair)
  {
    pair.second += increment_;
    return OB_SUCCESS;
  }
private:
  int64_t increment_;
};

} // namespace

////////////////////////////////////////////////////////////////////////////////
// class ObStopWordChecker
ObStopWordChecker::~ObStopWordChecker()
{
  destroy();
}

int ObStopWordChecker::init()
{
  int ret = OB_SUCCESS;
  
  

  if (inited_) {
    ret = OB_INIT_TWICE;
  } else if (OB_FAIL(stopword_set_.create(DEFAULT_STOPWORD_BUCKET_NUM, "StopWordSet", "StopWordSet"))) {
    LOG_WARN("fail to create stop word set", K(ret));
  } else {
    ObObjMeta stop_meta;
    stop_meta.set_varchar();
    stop_meta.set_collation_type(ObCollationType::CS_TYPE_UTF8MB4_GENERAL_CI);

    stopword_type_.set_meta(stop_meta);
    const int64_t stopword_count = sizeof(ob_stop_word_list) / sizeof(ob_stop_word_list[0]);
    for (int64_t i = 0; OB_SUCC(ret) && i < stopword_count; ++i) {
      ObFTWord stopword(STRLEN(ob_stop_word_list[i]), ob_stop_word_list[i], stopword_type_);
      if (OB_FAIL(stopword_set_.set_refactored(stopword))) {
        LOG_WARN("fail to set stop word", K(ret), K(stopword));
      }
    }

    if (OB_SUCC(ret)) {
      inited_ = true;
    }
  }
  return ret;
}

void ObStopWordChecker::destroy()
{
  if (inited_) {
    stopword_set_.destroy();
    inited_ = false;
  }
}

int ObStopWordChecker::check_stopword(const ObFTWord &word, bool &is_stopword)
{
  int ret = OB_SUCCESS;
  is_stopword = false;
  if (OB_UNLIKELY(!inited_)) {
    ret = OB_NOT_INIT;
    LOG_WARN("ObStopWordChecker hasn't been initialized", K(ret), K(inited_));
  } else if (OB_UNLIKELY(word.empty())) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("word is empty", K(ret), K(word));
  } else {
    const ObString src_str = word.get_word().get_string();
    bool is_ascii = false;
    if (is_ascii_stopword(src_str, is_ascii)) {
      is_stopword = true;
    } else if (is_ascii) {
      // The complete built-in stopword list is ASCII, and the parser has
      // already normalized these tokens to lowercase.
    } else {
      common::ObArenaAllocator allocator(lib::ObMemAttr("ChkStopWord"));
      common::ObString cmp_str;
      if (OB_FAIL(common::ObCharset::charset_convert(
                                         allocator,
                                         src_str,
                                         word.get_collation_type(),
                                         stopword_type_.get_collation_type(),
                                         cmp_str))) {
        LOG_WARN("fail to convert charset", K(ret), K(word), K(stopword_type_));
      } else {
        ObFTWord converted(cmp_str.length(), cmp_str.ptr(), stopword_type_);
        ret = stopword_set_.exist_refactored(converted);
        if (OB_HASH_NOT_EXIST == ret) {
          ret = OB_SUCCESS;
        } else if (OB_HASH_EXIST == ret) {
          is_stopword = true;
          ret = OB_SUCCESS;
        } else if (OB_SUCC(ret)) {
          ret = OB_ERR_UNEXPECTED;
          LOG_WARN("the exist of hastset shouldn't return success", K(ret), K(word), K(converted));
        } else {
          LOG_WARN("fail to do exist", K(ret), K(word), K(converted));
        }
      }
    }
  }
  return ret;
}

////////////////////////////////////////////////////////////////////////////////
// class ObAddWord
ObAddWord::ObAddWord(
    const ObFTParserProperty &property,
    const ObObjMeta &meta,
    const ObAddWordFlag &flag,
    common::ObIAllocator &allocator,
    ObFTWordMap &word_map)
  : word_meta_(meta),
    allocator_(allocator),
    word_map_(word_map),
    min_max_word_cnt_(0),
    non_stopword_cnt_(0),
    stopword_cnt_(0),
    min_token_size_(property.min_token_size_),
    max_token_size_(property.max_token_size_),
    flag_(flag)
{
}

int ObAddWord::process_word(
    const char *word,
    const int64_t word_len,
    const int64_t char_cnt,
    const int64_t word_freq)
{
  int ret = OB_SUCCESS;
  bool is_stopword = false;
  ObFTWord src_word(word_len, word, word_meta_);
  ObFTWord dst_word;
  if (OB_ISNULL(word) || OB_UNLIKELY(0 >= word_len || 0 >= char_cnt || 0 >= word_freq)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arguments", K(ret), KP(word), K(word_len), K(char_cnt), K(word_freq));
  } else if (is_min_max_word(char_cnt)) {
    ++min_max_word_cnt_;
    LOG_DEBUG("skip too small or large word", K(ret), K(src_word), K(char_cnt));
  } else if (OB_FAIL(casedown_word(src_word, dst_word))) {
    LOG_WARN("fail to casedown word", K(ret), K(src_word));
  } else if (OB_FAIL(check_stopword(dst_word, is_stopword))) {
    LOG_WARN("fail to check stopword", K(ret), K(dst_word));
  } else if (OB_UNLIKELY(is_stopword)) {
    ++stopword_cnt_;
    LOG_DEBUG("skip stopword", K(ret), K(dst_word));
  } else if (OB_FAIL(groupby_word(dst_word, word_freq))) {
    LOG_WARN("fail to groupby word into word map", K(ret), K(dst_word), K(word_freq));
  } else {
    non_stopword_cnt_ += word_freq;
    LOG_DEBUG("add word", K(ret), KP(word), K(word_len), K(char_cnt), K(word_freq), K(src_word), K(dst_word));
  }
  return ret;
}

bool ObAddWord::is_min_max_word(const int64_t c_len) const
{
  return flag_.min_max_word() && (c_len < min_token_size_ || c_len > max_token_size_);
}

int ObAddWord::casedown_word(const ObFTWord &src, ObFTWord &dst)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(src.empty())) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid src ft word", K(ret), K(src));
  } else if (flag_.casedown()) {
    const ObString src_str = src.get_word().get_string();
    bool is_ascii = true;
    bool needs_casedown = false;
    for (int64_t i = 0; i < src_str.length(); ++i) {
      const unsigned char ch = static_cast<unsigned char>(src_str.ptr()[i]);
      is_ascii = is_ascii && (ch < 0x80);
      needs_casedown = needs_casedown || (ch >= 'A' && ch <= 'Z');
    }
    if (is_ascii && !needs_casedown) {
      // Already lowercase ASCII: avoid allocation and charset conversion.
      dst = src;
    } else if (is_ascii) {
      // Lowercase ASCII in place using scratch allocator; the common case for
      // mixed Chinese/English documents contains only a few English words.
      char *buf = static_cast<char *>(allocator_.alloc(src_str.length()));
      if (OB_ISNULL(buf)) {
        ret = OB_ALLOCATE_MEMORY_FAILED;
        LOG_WARN("fail to allocate casedown buffer", K(ret), K(src_str.length()));
      } else {
        for (int64_t i = 0; i < src_str.length(); ++i) {
          const unsigned char ch = static_cast<unsigned char>(src_str.ptr()[i]);
          buf[i] = (ch >= 'A' && ch <= 'Z') ? static_cast<char>(ch + ('a' - 'A')) : src_str.ptr()[i];
        }
        ObFTWord tmp(src_str.length(), buf, word_meta_);
        dst = tmp;
      }
    } else {
      ObString dst_str;
      if (OB_FAIL(ObCharset::tolower(
                      word_meta_.get_collation_type(),
                      src_str,
                      dst_str,
                      allocator_))) {
        LOG_WARN("fail to tolower", K(ret), K(src), K(word_meta_));
      } else {
        ObFTWord tmp(dst_str.length(), dst_str.ptr(), word_meta_);
        dst = tmp;
      }
    }
  } else {
    dst = src;
  }
  return ret;
}

int ObAddWord::check_stopword(const ObFTWord &ft_word, bool &is_stopword)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(ft_word.empty())) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arguments", K(ret), K(ft_word));
  } else if (flag_.stopword()) {
    ObStopWordChecker *stop_word_checker = ObFTParsePluginData::instance().stop_word_checker();
    if (OB_ISNULL(stop_word_checker)) {
      ret = OB_ERR_UNEXPECTED;
      LOG_WARN("got null stop word checker", K(ret));
    } else if (OB_FAIL(stop_word_checker->check_stopword(ft_word, is_stopword))) {
      LOG_WARN("fail to check stopword", K(ret));
    }
  }
  return ret;
}

int ObAddWord::groupby_word(const ObFTWord &word, const int64_t word_freq)
{
  int ret = OB_SUCCESS;
  if (OB_UNLIKELY(word.empty() || word_freq <= 0)) {
    ret = OB_INVALID_ARGUMENT;
    LOG_WARN("invalid arguments", K(ret), K(word), K(word_freq));
  } else if (!flag_.groupby_word()) {
    if (OB_FAIL(word_map_.set_refactored(word, 1/*word count*/))) {
      LOG_WARN("fail to set fulltext word and count", K(ret), K(word));
    }
  } else {
    ObUpdateWordCount update_word_count(word_freq);
    if (OB_FAIL(word_map_.set_or_update(word, 1/*first occurrence*/, update_word_count))) {
      LOG_WARN("fail to set or update fulltext word count", K(ret), K(word), K(word_freq));
    }
  }
  return ret;
}

} // end namespace storage
} // end namespace oceanbase
